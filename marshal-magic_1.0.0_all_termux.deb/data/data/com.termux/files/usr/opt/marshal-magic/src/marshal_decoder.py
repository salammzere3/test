
from typing import CodeType

class MarshalDecoder:
    def __init__(self, bytecode: CodeType) -> None:
        self.bytecode = bytecode

    # def dump(self):
        