cd pycdc
cmake -S . -B build
cd build
make
